import hashlib
import os
import requests

def generate_hash(password: str) -> str:
    salt = os.urandom(32)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
    return salt + key

def verify_password(stored_password: bytes, provided_password: str) -> bool:
    salt = stored_password[:32]
    key = stored_password[32:]
    new_key = hashlib.pbkdf2_hmac('sha256', provided_password.encode('utf-8'), salt, 100000)
    return new_key == key

def fetch_crypto_price(coin: str, vs_currency: str = 'usd') -> float:
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={coin}&vs_currencies={vs_currency}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json().get(coin, {}).get(vs_currency, 0.0)
    return 0.0