from admin_bot.admin import main

if __name__ == "__main__":
    main()