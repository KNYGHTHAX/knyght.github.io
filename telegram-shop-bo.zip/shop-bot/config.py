import os
from dotenv import load_dotenv

load_dotenv()

SHOP_BOT_TOKEN = os.getenv("SHOP_BOT_TOKEN")
CRYPTO_API_URL = "https://api.coingecko.com/api/v3/simple/price"
SUPPORTED_COINS = ["bitcoin", "usd-coin", "litecoin"]