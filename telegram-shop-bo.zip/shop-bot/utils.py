import requests
from .config import CRYPTO_API_URL, SUPPORTED_COINS

def get_crypto_price(coin):
    if coin not in SUPPORTED_COINS:
        return None
    response = requests.get(f"{CRYPTO_API_URL}?ids={coin}&vs_currencies=usd")
    if response.status_code == 200:
        return response.json().get(coin, {}).get("usd")
    return None

def process_payment(payment_screenshot, txn_id):
    # Implement logic to process the payment (verify transaction ID, update order status, etc.)
    pass