from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, ConversationHandler
from common.database import init_db
from .config import SHOP_BOT_TOKEN
from .handlers import start, browse_products, view_product, add_to_cart, checkout, contact_us, handle_payment
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    init_db()
    updater = Updater(SHOP_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            "BROWSE_PRODUCTS": [CallbackQueryHandler(browse_products)],
            "VIEW_PRODUCT": [CallbackQueryHandler(view_product)],
            "ADD_TO_CART": [CallbackQueryHandler(add_to_cart)],
            "CHECKOUT": [CallbackQueryHandler(checkout)],
            "CONTACT_US": [CallbackQueryHandler(contact_us)],
            "HANDLE_PAYMENT": [MessageHandler(Filters.photo | Filters.text, handle_payment)],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    dp.add_handler(conv_handler)
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()