from shop_bot.shop import main

if __name__ == "__main__":
    main()