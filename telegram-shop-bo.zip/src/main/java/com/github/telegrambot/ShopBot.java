package com.github.telegrambot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopBot {

    public static void main(String[] args) {
        SpringApplication.run(ShopBot.class, args);
    }
}