from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from common.database import Base
import enum

class OrderStatus(enum.Enum):
    pending = "Pending"
    processing = "Processing"
    on_hold = "On Hold"
    completed = "Completed"
    failed = "Failed"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(String, unique=True, index=True)
    username = Column(String, index=True)
    full_name = Column(String)

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary key=True, index=True)
    name = Column(String, index=True)
    description = Column(String)
    price = Column(Float)
    thumbnail_url = Column(String)
    demo_video_url = Column(String)
    addons = relationship("Addon", back_populates="product")

class Addon(Base):
    __tablename__ = "addons"
    id = Column(Integer, primary key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"))
    name = Column(String)
    description = Column(String)
    price = Column(Float)
    demo_video_url = Column(String)
    product = relationship("Product", back_populates="addons")

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    product_id = Column(Integer, ForeignKey("products.id"))
    addon_id = Column(Integer, ForeignKey("addons.id"), nullable=True)
    status = Column(Enum(OrderStatus), default=OrderStatus.pending)
    payment_txn_id = Column(String, nullable=True)
    payment_screenshot_url = Column(String, nullable=True)
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    user = relationship("User")
    product = relationship("Product")
    addon = relationship("Addon", nullable=True)