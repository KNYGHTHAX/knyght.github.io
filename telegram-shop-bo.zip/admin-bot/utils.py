import pyotp
from .config import OTP_SECRET, SESSION_TIMEOUT_MINUTES
from datetime import datetime, timedelta

def send_otp():
    # Implement logic to send OTP to the admin's private bot
    pass

def verify_otp_code(otp_code):
    totp = pyotp.TOTP(OTP_SECRET)
    return totp.verify(otp_code)

def get_session_expiry_time():
    return datetime.utcnow() + timedelta(minutes=SESSION_TIMEOUT_MINUTES)