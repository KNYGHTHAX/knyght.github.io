from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import CallbackContext
from .utils import send_otp, verify_otp_code, get_session_expiry_time
from datetime import datetime, timedelta

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Welcome to the Admin Bot. Please enter the OTP sent to your private bot.")
    send_otp()
    return "VERIFY_OTP"

def verify_otp(update: Update, context: CallbackContext):
    otp_code = update.message.text
    if verify_otp_code(otp_code):
        context.user_data["authenticated"] = True
        context.user_data["session_expiry"] = get_session_expiry_time()
        update.message.reply_text("OTP verified! You are now logged in.", reply_markup=admin_main_menu())
        return "MANAGE_PRODUCTS"
    else:
        update.message.reply_text("Invalid OTP. Please try again.")
        return "VERIFY_OTP"

def manage_products(update: Update, context: CallbackContext):
    # Implement product management logic (add/edit/delete products)
    pass

def manage_orders(update: Update, context: CallbackContext):
    # Implement order management logic (view/update orders)
    pass

def broadcast_message(update: Update, context: CallbackContext):
    # Implement broadcast message logic
    pass

def admin_main_menu():
    keyboard = [
        [InlineKeyboardButton("Manage Products", callback_data="MANAGE_PRODUCTS")],
        [InlineKeyboardButton("Manage Orders", callback_data="MANAGE_ORDERS")],
        [InlineKeyboardButton("Broadcast Message", callback_data="BROADCAST_MESSAGE")],
    ]
    return InlineKeyboardMarkup(keyboard)