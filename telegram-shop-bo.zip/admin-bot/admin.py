from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, ConversationHandler
from common.database import init_db
from .config import ADMIN_BOT_TOKEN, ADMIN_PASSWORD, OTP_SECRET, SESSION_TIMEOUT_MINUTES
from .handlers import start, verify_otp, manage_products, manage_orders, broadcast_message
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    init_db()
    updater = Updater(ADMIN_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            "VERIFY_OTP": [MessageHandler(Filters.text, verify_otp)],
            "MANAGE_PRODUCTS": [CallbackQueryHandler(manage_products)],
            "MANAGE_ORDERS": [CallbackQueryHandler(manage_orders)],
            "BROADCAST_MESSAGE": [MessageHandler(Filters.text, broadcast_message)],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    dp.add_handler(conv_handler)
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()